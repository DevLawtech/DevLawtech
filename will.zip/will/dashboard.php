<?php
// Conexão com o banco de dados
include 'includes/db_connect.php';

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM funcionarios WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result->num_rows === 0) {
    die("Usuário não encontrado.");
}

$user = $user_result->fetch_assoc();
$nome_funcionario = $user['nome_completo']; // Assume que 'nome' é a coluna que contém o nome do funcionário
?>
<DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <title>Dashboard</title>
    <style>

    </style>
</head>
<body>
    <!-- Navbar lateral -->
    <div class="navbar" id="navbar">
        <div class="nav-header">InfoSec</div>
        <ul>
            <li><a href="#home" onclick="changeSection('home')">Home</a></li>
            <li><a href="whatsapp.php" onclick="changeSection('whatsapp')">Whatsapp</a></li>
            <li><a href="#sobre" onclick="changeSection('sobre')">Quem Somos</a></li>
            <li><a href="includes/logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Botão para abrir/fechar navbar -->
    <div class="navbar-toggle" id="toggleBtn" onclick="toggleNavbar()">☰</div>

    <!-- Conteúdo principal -->
    <div class="main-content" id="mainContent">
    <section id="home" class="section active">
            <h1>Home</h1>
            <p>Bem-vindo ao painel InfoSec <?php echo htmlspecialchars($nome_funcionario); ?></p>
        </section>
        <section id="whatsapp" class="section">
        <br>
            <h1>Whatsapp Integration - Redirecionando...</h1>
            <br>
            <div class="form-container">
                <h2>whatsapp</h2>
                <br>
                
                <p>Redirecionando...</p>
            </div>
        </section>
        <section id="sobre" class="section">
    <div class="container-descoberta-lista">
    <div class="form-container">
        <center>
            <h1>SECURITYNET BRASIL</h1>
            <h3>Gabriel Moura Machado</h3>
        </center>

        <div class="servicos">
            <h2>Serviços</h2>
            <ul>
                <li><strong>Identidade Visual:</strong> Criação e desenvolvimento de logotipos e identidade de marca.</li>
                <li><strong>Marketing Digital:</strong> Estratégias de marketing focadas em SEO, mídias sociais e publicidade online.</li>
                <li><strong>Análise de Segurança:</strong> Avaliação de vulnerabilidades e implementação de medidas de proteção.</li>
                <li><strong>Soluções em Tecnologia:</strong> Consultoria e implementação de soluções tecnológicas sob medida.</li>
                <li><strong>Desenvolvimento de Aplicativos:</strong> Criação de aplicativos personalizados para diversas plataformas.</li>
            </ul>
        </div>

        
<br><hr>

        <div class="plano-captura">
            <h2>Plano de Captura de Clientes</h2>
            <p>
                Nosso plano utiliza um sistema automatizado que realiza pesquisas avançadas via Google Dorking para identificar sites e servidores vulneráveis. As vulnerabilidades incluem SQL Injection (SQLi), Cross-Site Scripting (XSS), Remote Code Execution (RCE), Local File Inclusion (LFI), Remote File Inclusion (RFI) e Insecure Direct Object Reference (IDOR).
            </p>
            <p>
                O bot coleta informações via WHOIS e web scraping, gerando um relatório detalhado para os representantes comerciais, que utilizam essas informações para contatar potenciais clientes.
            </p>
        </div>

        
<br><hr>

        <div class="roteiro-abordagem">
            <h2>Roteiro de Abordagem</h2>
            <a href="roteiro.html"><p>Olá, eu sou o <strong>$REPRESENTANTE</strong>, representante comercial da SecurityNet Brasil...</p></a>
        </div>

        
<br><hr>

        <div class="colaboradores">
            <h2>Colaboradores e Funções</h2>
            <ul>
                <li><strong>Gabriel Moura:</strong> Administrador Geral - Analista de Segurança e Desenvolvedor Back End</li>
                <li><strong>Thiago TH:</strong> CEO - Designer e Representante comercial</li>
                <li><strong>William Vasconcelos </strong> Desenvolvedor - Designer e Representante comercial</li>
            </ul>
        </div>

        
<br><hr>
        <div class="objetivo">
            <h2>Objetivo</h2>
            <p>
                Nosso principal objetivo é construir uma base sólida de empresas-clientes que contribuam com uma mensalidade, visando o crescimento contínuo dessa lista. Isso garantirá uma receita estável e recorrente, proporcionando uma renda mensal consistente para todos os colaboradores.
            </p>
        </div>
    </div>

        </div>
</section>
 

    </div>

    <script>
        // Função para ativar a seção com base no fragmento da URL
        function activateSectionFromHash() {
        // Obtém o fragmento da URL (por exemplo, "#em-andamento")
        const hash = window.location.hash;

        // Remove a classe 'active' de todas as seções
        const sections = document.querySelectorAll('.section');
        sections.forEach(section => {
            section.classList.remove('active');
        });

        // Adiciona a classe 'active' à seção com o ID correspondente ao fragmento
        if (hash) {
            const targetSection = document.querySelector(hash);
            if (targetSection) {
                targetSection.classList.add('active');
            }
        } else {
            // Se não houver fragmento, ativa a seção padrão (pode ser a 'home')
            document.getElementById('home').classList.add('active');
        }
    }

    // Ativa a seção correta quando a página é carregada
    window.addEventListener('load', activateSectionFromHash);

    // Ativa a seção correta quando o fragmento da URL muda (caso o usuário use navegação no navegador)
    window.addEventListener('hashchange', activateSectionFromHash);

    // Função para abrir/fechar navbar
    function toggleNavbar() {
        const navbar = document.getElementById('navbar');
        navbar.classList.toggle('open');
    }

    // Função para mudar de seção sem recarregar a página
    function changeSection(sectionId) {
        // Esconder todas as seções
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        // Mostrar a seção clicada
        document.getElementById(sectionId).classList.add('active');
    }
    // Função para abrir o modal
function openModal(clientId) {
    document.getElementById('modal-' + clientId).style.display = "block";
}

// Função para fechar o modal
function closeModal(clientId) {
    document.getElementById('modal-' + clientId).style.display = "none";
}

    </script>
</body>
</html>
