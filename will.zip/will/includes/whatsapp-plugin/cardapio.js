const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const db = require('/var/www/db1'); // Conexão com o banco de dados

const client = new Client({
    authStrategy: new LocalAuth(), // Usa LocalAuth para persistência da sessão
});
const app = express();
app.use(bodyParser.json());

// Gerar QR Code para autenticar no WhatsApp
client.on('qr', (qr) => {
    console.log('QR Code generated, scan it with WhatsApp.');
    qrcode.generate(qr, { small: true });
});

// Indica que o bot está pronto
client.on('ready', () => {
    console.log('WhatsApp bot is ready!');
});

// Função para formatar corretamente o chatId
const formatChatId = (chatId) => {
    if (!chatId.includes('@')) {
        return `${chatId}@c.us`;
    }
    return chatId;
};

// Função para enviar imagens como documentos
const sendImageAsDocument = async (chatId, imagePath) => {
    try {
        const media = await client.sendMessage(chatId, fs.readFileSync(imagePath), { sendMediaAsDocument: true });
        console.log(`Image sent successfully to ${chatId}: ${media.id._serialized}`);
    } catch (err) {
        console.error('Failed to send image:', err);
    }
};

// Função para salvar mensagem recebida no banco de dados
client.on('message', async (msg) => {
    const contact = await msg.getContact();
    const chatId = formatChatId(msg.from);
    const text = msg.body;

    // Insere mensagem recebida no banco de dados
    db.query("INSERT INTO messages (contact_name, phone_number, message, direction, timestamp) VALUES (?, ?, ?, ?, ?)", 
             [contact.pushname, chatId, text, 'received', new Date()], (err) => {
        if (err) console.error(err);
    });

    // Verifica se a mensagem é "cardapio"
    if (text.toLowerCase() === 'cardapio') {
        console.log(`Sending 'cardapio' image to ${chatId}`);
        const imagePath = path.resolve('cardapio.jpg'); // Caminho da imagem 'cardapio.jpg'
        await sendImageAsDocument(chatId, imagePath);
    }
});

// Endpoint para enviar uma mensagem a partir do PHP (POST)
app.post('/send-message', (req, res) => {
    const { chatId, message } = req.body;
    const formattedChatId = formatChatId(chatId);

    console.log(`Received request to send message to ${formattedChatId}: ${message}`);
    
    client.sendMessage(formattedChatId, message).then(() => {
        console.log(`Message sent to ${formattedChatId}: ${message}`);
        res.send('Message sent');
    }).catch((err) => {
        console.error('Failed to send message:', err);
        res.status(500).send('Failed to send message');
    });
});

// Inicializa o cliente do WhatsApp
client.initialize();

// Inicia o servidor Express
app.listen(3000, () => console.log('Server running on port 3000'));
