const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const db = require('/var/www/db1'); // Conexão com o banco de dados

const client = new Client({
    authStrategy: new LocalAuth(), // Usa LocalAuth para persistência da sessão
});
app.use(bodyParser.json());

// Gerar QR Code para autenticar no WhatsApp
client.on('qr', (qr) => {
    console.log('QR Code generated, scan it with WhatsApp.');
    qrcode.generate(qr, { small: true });
});

// Indica que o bot está pronto
client.on('ready', () => {
    console.log('WhatsApp bot is ready!');
    checkPendingMessages(); // Inicia a verificação de mensagens pendentes
});

// Função para formatar corretamente o chatId
const formatChatId = (chatId) => {
    if (!chatId.includes('@')) {
        // Verifica se o ID é um número de telefone, adiciona o sufixo "@c.us"
        return `${chatId}@c.us`;
    }
    return chatId;
};

// Função para enviar mensagens pendentes
const sendPendingMessages = () => {
    console.log('Checking for pending messages...');
    db.query("SELECT * FROM messages WHERE direction = 'sent' AND status = 'pending'", (err, results) => {
        if (err) {
            console.error('Error fetching pending messages:', err);
            return;
        }
        results.forEach((message) => {
            const formattedChatId = formatChatId(message.phone_number);
            console.log(`Sending message to ${formattedChatId}: ${message.message}`);
            client.sendMessage(formattedChatId, message.message).then(() => {
                console.log(`Message sent to ${formattedChatId}: ${message.message}`);
                // Atualiza o status da mensagem para 'sent' após o envio
                db.query("UPDATE messages SET status = 'sent' WHERE id = ?", [message.id], (err) => {
                    if (err) console.error('Error updating message status:', err);
                });
            }).catch((err) => {
                console.error('Failed to send message:', err);
            });
        });
    });
};

// Função para verificar e enviar mensagens pendentes periodicamente
const checkPendingMessages = () => {
    sendPendingMessages(); // Verifica e envia mensagens pendentes
    setInterval(sendPendingMessages, 3000); // Verifica a cada 30 segundos
};

// Função para salvar mensagem recebida no banco de dados
client.on('message', async (msg) => {
    const contact = await msg.getContact();
    const chatId = formatChatId(msg.from); // Formatar o chatId corretamente
    const text = msg.body;

    // Insere mensagem recebida no banco de dados
    db.query("INSERT INTO messages (contact_name, phone_number, message, direction, timestamp) VALUES (?, ?, ?, ?, ?)", 
             [contact.pushname, chatId, text, 'received', new Date()], (err) => {
        if (err) console.error(err);
    });

    // Responder automaticamente com uma mensagem de saudação (exemplo)
    if (text.toLowerCase() === 'olá') {
        console.log(`Responding to ${chatId} with a greeting message.`);
        client.sendMessage(chatId, 'Olá! Como posso ajudar você?');
    }
});

// Endpoint para enviar uma mensagem a partir do PHP (POST)
app.post('/send-message', (req, res) => {
    const { chatId, message } = req.body;
    const formattedChatId = formatChatId(chatId); // Formatar o chatId corretamente

    console.log(`Received request to send message to ${formattedChatId}: ${message}`);

    // Insere a mensagem no banco de dados com status 'pending'
    db.query("INSERT INTO messages (phone_number, message, direction, status, timestamp) VALUES (?, ?, ?, 'pending', ?)", 
             [formattedChatId, message, 'sent', new Date()], (err) => {
        if (err) {
            console.error('Error saving message to database:', err);
            res.status(500).send('Failed to save message');
            return;
        }

        // Enviar mensagem imediatamente
        client.sendMessage(formattedChatId, message).then(() => {
            console.log(`Message sent to ${formattedChatId}: ${message}`);
            // Atualiza o status da mensagem para 'sent' após o envio
            db.query("UPDATE messages SET status = 'sent' WHERE phone_number = ? AND message = ? AND status = 'pending'", [formattedChatId, message], (err) => {
                if (err) console.error('Error updating message status:', err);
            });
            res.send('Message sent');
        }).catch((err) => {
            console.error('Failed to send message:', err);
            res.status(500).send('Failed to send message');
        });
    });
});

// Endpoint para responder uma mensagem via interface web (POST)
app.post('/send-response', (req, res) => {
    const { chatId, response } = req.body;
    const formattedChatId = formatChatId(chatId); // Formatar o chatId corretamente

    console.log(`Received request to send response to ${formattedChatId}: ${response}`);

    client.sendMessage(formattedChatId, response).then(() => {
        // Salva a resposta enviada no banco de dados
        db.query("INSERT INTO messages (phone_number, message, direction, status, timestamp) VALUES (?, ?, ?, 'sent', ?)", 
                 [formattedChatId, response, 'sent', new Date()], (err) => {
            if (err) console.error(err);
        });
        res.send('Response sent');
    }).catch((err) => {
        console.error('Failed to send response:', err);
        res.status(500).send('Failed to send response');
    });
});

// Inicializa o cliente do WhatsApp
client.initialize();

// Inicia o servidor Express
app.listen(3000, () => console.log('Server running on port 3000'));
