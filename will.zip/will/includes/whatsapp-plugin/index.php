<?php
header("Location: ../index.php");
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InfoSec abat</title>
</head>
<body>
    <h1>Titulo</h1>

</body>
</html>