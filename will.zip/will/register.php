<?php

    $message = ""; // Variável para armazenar mensagens de sucesso ou erro

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Conectar ao banco de dados
        include 'includes/db_connect.php';

        // Coletar e sanitizar os dados do formulário
        $nome_completo = mysqli_real_escape_string($conn, $_POST['nome_completo']);
        $cpf = mysqli_real_escape_string($conn, $_POST['cpf']);
        $data_nasc = mysqli_real_escape_string($conn, $_POST['data_nasc']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $contato = mysqli_real_escape_string($conn, $_POST['contato']);
        $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT); // Criptografa a senha
        $type = mysqli_real_escape_string($conn, $_POST['type']);

        // Inserir os dados no banco de dados
        $sql = "INSERT INTO funcionarios (nome_completo, cpf, data_nasc, email, contato, senha, type) 
                VALUES ('$nome_completo', '$cpf', '$data_nasc', '$email', '$contato', '$senha', '$type')";

        if (mysqli_query($conn, $sql)) {
            $message = "Registro bem-sucedido!";
        } else {
            $message = "Erro ao registrar: " . mysqli_error($conn);
        }

        // Fechar conexão
        mysqli_close($conn);
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/register.css">
    <title>Registrar-se</title>
    <style>
        
    </style>
</head>
<body>
    <div class="container">
        <h1>Registrar-se</h1>
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <input type="text" name="nome_completo" placeholder="Nome Completo" required><br>
            <input type="text" name="cpf" placeholder="CPF" required><br>
            <input type="date" name="data_nasc" placeholder="Data de Nascimento" required><br>
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="text" name="contato" placeholder="Contato (Telefone)" required><br>
            <input type="password" name="senha" placeholder="Senha" required><br>
            <select name="type" required>
                <option value="0">Funcionário</option>
                <option value="1">Admin</option>
            </select><br>
            <button type="submit">Registrar</button>
        </form>
        <br>
        <a href="login.php">Já sou registrado</a>
    </div>
</body>
</html>
