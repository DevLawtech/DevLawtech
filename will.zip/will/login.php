<?php
// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
include 'includes/db_connect.php'; // Ajuste o caminho conforme necessário

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Coletar e sanitizar dados do formulário
    $cpf = mysqli_real_escape_string($conn, $_POST['cpf']);
    $password = $_POST['password'];

    // Consultar o banco de dados
    $sql = "SELECT id, senha, type FROM funcionarios WHERE cpf = '$cpf'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        // Verificar a senha
        if (password_verify($password, $row['senha'])) {
            // Senha correta, iniciar sessão
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_type'] = $row['type'];
            header("Location: dashboard.php"); // Redirecionar para o dashboard
            exit();
        } else {
            $login_error = "CPF ou senha incorretos.";
        }
    } else {
        $login_error = "CPF não encontrado.";
    }

    // Fechar conexão
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/login.css">
    <title>Login - InfoSec</title>
    <style>
        
    </style>
</head>
<body>
    <div class="container">
        <h1>Painel de Login</h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <input type="text" name="cpf" placeholder="CPF" required>
            <input type="password" name="password" placeholder="Senha" required>
            <button type="submit">Entrar</button>
            <?php if (isset($login_error)) { echo '<p class="error">' . $login_error . '</p>'; } ?>
            <br><br>
            <a href="register.php">Trabalhe conosco</a>
        </form>
    </div>
</body>
</html>
