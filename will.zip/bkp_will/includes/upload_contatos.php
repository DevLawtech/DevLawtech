<?php
include 'db_connect.php';
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM empresas WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result->num_rows === 0) {
    die("Usuário não encontrado.");
}

$user = $user_result->fetch_assoc();
$nome_funcionario = $user['nome_completo']; // Assume que 'nome' é a coluna que contém o nome do funcionário
$cpf = $user['cpf'];

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar com o banco de dados: " . $e->getMessage());
}

// Verifica se o arquivo foi enviado
if (isset($_FILES['file'])) {
    $file = $_FILES['file']['tmp_name'];
    $owner = $cpf; // CPF/CNPJ do usuário logado

    // Lê o conteúdo do arquivo
    $fileContent = file_get_contents($file);
    $lines = explode("\n", $fileContent);

    // Armazena os números que já foram inseridos
    $numeros_inseridos = [];

    // Processa cada linha do arquivo
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;

        // Divide a linha pelos separadores de vírgula
        $parts = explode(',', $line);

        // Extrai o nome do contato (concatenando as partes iniciais para formar o nome)
        $nome_contato = trim($parts[0] . ' ' . $parts[1] . ' ' . $parts[2]);

        // Percorre as partes para encontrar todos os números de telefone
        foreach ($parts as $part) {
            $part = trim($part); // Remove espaços em branco

            // Verifica se a parte contém um número de telefone válido
            if ((strpos($part, '+') !== false || ctype_digit($part)) && strlen($part) >= 10) {
                // Remove caracteres não numéricos
                $numero = preg_replace('/\D/', '', $part);

                // Limita o tamanho do número para 20 caracteres, se necessário
                $numero = substr($numero, 0, 20);

                // Verifica se o contato e número já existem no banco de dados para evitar duplicação
                $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM contatos WHERE owner = :owner AND nome_contato = :nome_contato AND numero = :numero");
                $checkStmt->execute([
                    ':owner' => $owner,
                    ':nome_contato' => $nome_contato,
                    ':numero' => $numero
                ]);
                $exists = $checkStmt->fetchColumn();

                // Só insere se o contato e o número ainda não existirem
                if ($exists == 0) {
                    $stmt = $pdo->prepare("INSERT INTO contatos (owner, nome_contato, numero) VALUES (:owner, :nome_contato, :numero)");
                    $stmt->execute([
                        ':owner' => $owner,
                        ':nome_contato' => $nome_contato,
                        ':numero' => $numero
                    ]);
                    // Adiciona o número à lista de números inseridos
                    $numeros_inseridos[] = $numero;
                }
            }
        }
    }

    header("Location: ../dashboard.php#home");
    exit();
} else {
    echo "Nenhum arquivo enviado.";
}
?>
