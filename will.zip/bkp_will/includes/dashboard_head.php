
<?php
// Conexão com o banco de dados
include 'db_connect.php';

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM empresas WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result->num_rows === 0) {
    die("Usuário não encontrado.");
}

$user = $user_result->fetch_assoc();
$nome_funcionario = $user['nome_completo']; // Assume que 'nome' é a coluna que contém o nome do funcionário
$cpf = $user['cpf'];

// consulta lista de contatos 
// Verifique se $cpf está definido
if (isset($cpf)) {
    // Recuperar contatos do usuário logado sem duplicados
    $sql = "SELECT MIN(nome_contato) AS nome_contato, numero FROM contatos WHERE owner = ? GROUP BY numero";
    $stmt = $conn->prepare($sql);
    
    // Verifica se a preparação foi bem-sucedida
    if ($stmt) {
        $stmt->bind_param("s", $cpf); // Usa "s" se $cpf for uma string
        $stmt->execute();
        $result = $stmt->get_result();
    }
}
?>