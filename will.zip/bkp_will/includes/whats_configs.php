<?php
// Incluir o arquivo de conexão
include 'db_connect.php';

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Função para buscar todos os contatos
function getContacts($conn) {
    $sql = "SELECT DISTINCT contact_name, phone_number FROM messages";
    $result = $conn->query($sql);
    return $result;
}

// Função para buscar as mensagens de um contato específico
if (isset($_GET['contact'])) {
    $contact = $_GET['contact'];
    $stmt = $conn->prepare("SELECT * FROM messages WHERE contact_name = ?");
    $stmt->bind_param("s", $contact);
    $stmt->execute();
    $messages = $stmt->get_result();
    $message_list = [];
    while ($row = $messages->fetch_assoc()) {
        $message_list[] = $row;
    }
    echo json_encode($message_list);
    exit;
}

// Função para buscar o nome completo do usuário
function getFullName($conn, $user_id) {
    $stmt = $conn->prepare("SELECT nome_completo FROM empresas WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['nome_completo'];
}

// Função para enviar uma mensagem
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $contact_name = $_POST['contact_name'];
    $phone_number = $_POST['phone_number'];
    $message = $_POST['message'];
    $direction = "sent";  // Direção sempre será 'sent' para este script
    $user_id = $_SESSION['user_id'];

    // Buscar o nome completo do usuário
    $full_name = getFullName($conn, $user_id);
    $nomes = explode(" ", $full_name);
    
    // Personalizar a mensagem
    $msg = '*'.$nomes[0].' Infosec*: '.$message;

    // Inserir a mensagem no banco de dados
    $stmt = $conn->prepare("INSERT INTO messages (contact_name, phone_number, message, direction) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $contact_name, $phone_number, $msg, $direction);

    if ($stmt->execute()) {
        echo "Mensagem enviada com sucesso!";
    } else {
        echo "Erro ao enviar mensagem!";
    }
    exit;
}
?>
