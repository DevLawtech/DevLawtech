<?php
include 'db_connect.php'; // Inclui a conexão com o banco de dados

session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Função para buscar todos os contatos
function getContacts($conn) {
    $sql = "SELECT contact_name, phone_number, MAX(timestamp) AS last_message_time
            FROM messages
            GROUP BY contact_name, phone_number
            ORDER BY last_message_time DESC";
    $result = $conn->query($sql);
    
    $contacts = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $contacts[] = $row;
        }
    }
    return $contacts;
}

// Retornar a lista de contatos como JSON
header('Content-Type: application/json');
echo json_encode(getContacts($conn));
?>
