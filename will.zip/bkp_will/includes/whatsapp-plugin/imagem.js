const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require('fs');

// Criação do cliente
const client = new Client({
    authStrategy: new LocalAuth()
});

// Gera o QR Code no terminal
client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
});

// Quando o cliente estiver pronto
client.on('ready', () => {
    console.log('Bot está pronto!');
});

// Função para enviar uma imagem
const sendImage = async (chatId, imagePath) => {
    const media = await client.sendMessage(chatId, {
        media: fs.readFileSync(imagePath),
        caption: 'Aqui está a imagem!'
    });
    console.log('Imagem enviada:', media);
};

// Função para enviar um áudio
const sendAudio = async (chatId, audioPath) => {
    const media = await client.sendMessage(chatId, {
        media: fs.readFileSync(audioPath)
    });
    console.log('Áudio enviado:', media);
};

// Função para enviar um documento
const sendDocument = async (chatId, documentPath) => {
    const media = await client.sendMessage(chatId, {
        media: fs.readFileSync(documentPath),
        caption: 'Aqui está o documento!'
    });
    console.log('Documento enviado:', media);
};

// Exemplo de uso
client.on('message', async message => {
    if (message.body === '!imagem') {
        await sendImage(message.from, 'caminho/para/imagem.jpg');
    } else if (message.body === '!audio') {
        await sendAudio(message.from, 'caminho/para/audio.mp3');
    } else if (message.body === '!documento') {
        await sendDocument(message.from, 'caminho/para/documento.pdf');
    }
});

// Iniciar o cliente
client.initialize();
