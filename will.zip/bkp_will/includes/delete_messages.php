<?php
include 'db_connect.php';

session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Verifica se o pedido é do tipo POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // SQL para deletar todas as mensagens
    $sql = "DELETE FROM messages";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode([
            "success" => true,
            "message" => "Histórico de mensagens deletado com sucesso!"
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Erro ao deletar histórico: " . $conn->error
        ]);
    }
    
    $conn->close();
} else {
    // Caso a requisição não seja POST
    echo json_encode([
        "success" => false,
        "message" => "Método não permitido. Utilize uma requisição POST."
    ]);
}
?>
