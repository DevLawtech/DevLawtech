<?php
$servername = "localhost"; // Endereço do servidor MySQL
$username = "multi_bot";   // Nome de usuário MySQL
$password = "lol123;";     // Senha MySQL
$dbname = "multi_call";    // Novo nome do banco de dados unificado

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>
