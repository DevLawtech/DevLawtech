<?php
// Conexão com o banco de dados
include 'includes/whats_configs.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="SHORTCUT ICON" href="logo.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/zap_styles2.css">
    <title>WhatsApp Secnet</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            height: 100vh;
            background-color: #f0f0f0;
        }
        .sidebar {
            width: 300px;
            background-color: #075E54;
            color: white;
            padding: 20px;
            overflow-y: auto;
            transition: transform 0.3s ease;
            transform: translateX(-100%); /* Inicialmente oculto */
            position: fixed; /* Para sobrepor o conteúdo */
            top: 0;
            left: 0;
            height: 100%;
        }
        .sidebar.open {
            transform: translateX(0); /* Abre a sidebar */
        }
        .chat-area {
            flex-grow: 1;
            padding: 20px;
            background-color: white;
            display: flex;
            flex-direction: column;
            margin-left: 0;
            transition: margin-left 0.3s ease;
        }
        .chat-area.open {
            margin-left: 300; /* Remove espaço quando a sidebar está aberta */
            transition: margin-left 0.3s ease;
        }
        .contact-list {
            margin-top: 20px;
            height: 450px;
        }
        .buttons-list {
            margin-top: 10px;
        }
        .messages {
            flex-grow: 1;
            overflow-y: auto;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
            display: flex;
            flex-direction: column;
            gap: 10px; /* Espaço entre os balões */
        }
        .message {
            padding: 10px;
            border-radius: 15px;
            max-width: 70%; /* Limite de largura para os balões */
            position: relative;
            display: inline-block;
        }
        .message.sent {
            background-color: #dcf8c6; /* Cor do balão enviado */
            align-self: flex-end; /* Alinha o balão à direita */
            border-top-left-radius: 0; /* Remove o canto superior esquerdo */
        }
        .message.received {
            background-color: #fff; /* Cor do balão recebido */
            align-self: flex-start; /* Alinha o balão à esquerda */
            border-top-right-radius: 0; /* Remove o canto superior direito */
        }
        .input-area {
            display: flex;
        }
        .input-area input {
            flex-grow: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .input-area button {
            padding: 10px;
            background-color: #075E54;
            color: white;
            border: none;
            border-radius: 5px;
            margin-left: 10px;
            cursor: pointer;
        }
        .input-area button:hover {
            background-color: #0B7E8E;
        }
        .toggle-button {
            position: absolute; top: 10px; right: 10px;width:50px;height:50px;background-color:blue;opacity:2%;
        }
        .toggle-button:hover {
            background-color:#075E54;
            opacity:75%;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 300px;
            }
            .chat-area {
                margin-left: 0px;
            }
        }
        @media (max-width: 480px) {
            .sidebar {
                width: 350px;
            }
            .chat-area {
                margin-left: 0px;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <a href="dashboard.php#home"> &larr; </a>
        <h2>Contatos</h2>
        <div class="buttons-list">
            <button id="newCallBtn">Novo</button>
            <div id="modal1">
                <div id="modal1Content">
                    <span class="close1">&times;</span>
                    <h2>Enviar Mensagem</h2>
                    <input type="text" id="phone_number" placeholder="Número do contato">
                    <textarea id="message" placeholder="Digite sua mensagem aqui"></textarea>
                    <button id="sendBtnmodal">Enviar</button>
                </div>
            </div>
            <button id="multi_call"><a href="multi_stream.php">Multi</a></button>
            <button id="multi_call"><a href="distribuited_stream.php">Massivo</a></button>
        </div>
        <div class="contact-list"></div>
        <div class="buttons-list">
            <button id="erase_data" style="width:300px;">Limpar</button>
        </div>
    </div>

    <div class="chat-area" id="chatArea">
        <div class="messages" id="messages">
            <p>Selecione um contato para ver as mensagens.</p>
        </div>

        <div class="input-area">
            <input type="text" id="messageInput" placeholder="Digite sua mensagem">
            <button id="sendButton">Enviar</button>
        </div>
    </div>

    <button class="toggle-button" id="toggleSidebar" style="">&#9776;</button>

    <script src="assets/js/zap.js"></script>
    <script>
       const sidebar = document.getElementById('sidebar');
const chatArea = document.getElementById('chatArea');
const toggleSidebar = document.getElementById('toggleSidebar');

// Função para adicionar mensagem
function addMessage(text, isSent) {
    const messagesDiv = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', isSent ? 'sent' : 'received');
    messageDiv.textContent = text;
    messagesDiv.appendChild(messageDiv);
    messagesDiv.scrollTop = messagesDiv.scrollHeight; // Rola para a última mensagem

    // Fecha a sidebar se estiver aberta
    if (sidebar.classList.contains('open')) {
        sidebar.classList.remove('open');
        chatArea.classList.add('open'); // Garante que a chatArea fica visível
    }
}

// Alterna a sidebar ao clicar no botão
toggleSidebar.onclick = () => {
    sidebar.classList.toggle('open');
    chatArea.classList.toggle('open');
};

// Exemplo de uso ao enviar mensagem
document.getElementById('sendButton').onclick = () => {
    const input = document.getElementById('messageInput');
    if (input.value.trim()) {
        addMessage(input.value, true); // Mensagem enviada
        input.value = ''; // Limpa a caixa de entrada
    }
};


    </script>
</body>
</html>
