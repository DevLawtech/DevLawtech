// Variáveis de referência aos elementos
const modal = document.getElementById("modal1");
const newCallBtn = document.getElementById("newCallBtn");
const closeModalBtn = document.getElementsByClassName("close1")[0];
const sendBtn = document.getElementById("sendBtnmodal");

// Abre o modal quando o botão "New Call" for clicado
newCallBtn.onclick = function() {
    modal.style.display = "block";
}

// Fecha o modal quando o botão de fechar for clicado
closeModalBtn.onclick = function() {
    modal.style.display = "none";
}

// Fecha o modal ao clicar fora do conteúdo
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Função para enviar a mensagem via API
sendBtn.onclick = function() {
    const phoneNumber = document.getElementById("phone_number").value;
    const message = document.getElementById("message").value;

    if (!phoneNumber || !message) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // Desabilita o botão para evitar múltiplos cliques
    sendBtn.disabled = true;

    // Realiza a requisição com Fetch API
    fetch(`api.php?key=batata&phone_number=${encodeURIComponent(phoneNumber)}&message=${encodeURIComponent(message)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Mensagem enviada com sucesso!");
            } else {
                alert("Erro ao enviar a mensagem: " + data.message);
            }
            // Reabilita o botão
            sendBtn.disabled = false;
            // Fecha o modal
            modal.style.display = "none";
        })
        .catch(error => {
            alert("Erro na requisição: " + error);
            sendBtn.disabled = false;
        });
}

function updateContactList() {
    fetch('includes/get_contacts.php')
        .then(response => response.json())
        .then(data => {
            const contactListDiv = document.querySelector('.contact-list');
            contactListDiv.innerHTML = ''; // Limpar lista anterior

            if (data.length > 0) {
                data.forEach(contact => {
                    const contactDiv = document.createElement('div');
                    contactDiv.classList.add('contact');
                    contactDiv.setAttribute('data-contact-name', contact.contact_name);
                    contactDiv.setAttribute('data-phone-number', contact.phone_number);
                    contactDiv.innerText = contact.contact_name;
                    contactDiv.addEventListener('click', () => {
                        // Função para lidar com o clique em um contato
                        selectedContact = contact.contact_name;
                        selectedPhoneNumber = contact.phone_number;
                        loadMessages(selectedContact);
                    });
                    contactListDiv.appendChild(contactDiv);
                });
            } else {
                contactListDiv.innerHTML = '<p>Nenhum contato encontrado.</p>';
            }
        })
        .catch(error => {
            console.error('Erro:', error);
        });
}

// Atualizar lista de contatos a cada 3 segundos (3000 milissegundos)
setInterval(updateContactList, 3000);

// Carregar contatos inicialmente
updateContactList();

let selectedContact = null;
        let selectedPhoneNumber = null;

        // Adicionar evento de clique para os contatos
        document.querySelectorAll('.contact').forEach(contact => {
            contact.addEventListener('click', () => {
                selectedContact = contact.getAttribute('data-contact-name');
                selectedPhoneNumber = contact.getAttribute('data-phone-number');
                loadMessages(selectedContact);
                sidebar.classList.remove('open');
            });
        });

        // Carregar as mensagens de um contato
        function loadMessages(contactName) {
            fetch(`whatsapp.php?contact=${contactName}`)
                .then(response => response.json())
                .then(data => {
                    const messagesDiv = document.getElementById('messages');
                    messagesDiv.innerHTML = '';

                    data.forEach(message => {
                        const messageDiv = document.createElement('div');
                        messageDiv.classList.add('message', message.direction);
                        messageDiv.innerText = message.message;
                        messagesDiv.appendChild(messageDiv);
                    });
                });
        }

        // apagar registros
        document.getElementById('erase_data').addEventListener('click', () => {
    if (confirm("Você tem certeza que deseja deletar todas as mensagens?")) {
        fetch('includes/delete_messages.php', {
            method: 'POST'
        })
        .then(response => response.text())
        .then(result => {
            alert("Mensagens apagadas com sucesso!");
            // Opcional: Atualizar a interface do usuário ou redirecionar para uma página de sucesso
        })
        .catch(error => {
            console.error('Erro:', error);
        });
    }
});
        // Enviar uma mensagem
        document.getElementById('sendButton').addEventListener('click', () => {
            const messageInput = document.getElementById('messageInput');
            const message = messageInput.value;

            if (message && selectedContact) {
                const formData = new FormData();
                formData.append('contact_name', selectedContact);
                formData.append('phone_number', selectedPhoneNumber);
                formData.append('message', message);

                fetch('whatsapp.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    console.log(data);
                    loadMessages(selectedContact);
                    messageInput.value = '';
                });
            }
        });

        // Função para atualizar as mensagens periodicamente
        function refreshMessages() {
            if (selectedContact) {
                loadMessages(selectedContact);
            }
        }

        // Atualiza as mensagens a cada 5 segundos
        setInterval(refreshMessages, 5000);