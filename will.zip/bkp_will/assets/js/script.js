        // Função para ativar a seção com base no fragmento da URL
        function activateSectionFromHash() {
            // Obtém o fragmento da URL (por exemplo, "#em-andamento")
            const hash = window.location.hash;
    
            // Remove a classe 'active' de todas as seções
            const sections = document.querySelectorAll('.section');
            sections.forEach(section => {
                section.classList.remove('active');
            });
    
            // Adiciona a classe 'active' à seção com o ID correspondente ao fragmento
            if (hash) {
                const targetSection = document.querySelector(hash);
                if (targetSection) {
                    targetSection.classList.add('active');
                }
            } else {
                // Se não houver fragmento, ativa a seção padrão (pode ser a 'home')
                document.getElementById('home').classList.add('active');
            }
        }
    
        // Ativa a seção correta quando a página é carregada
        window.addEventListener('load', activateSectionFromHash);
    
        // Ativa a seção correta quando o fragmento da URL muda (caso o usuário use navegação no navegador)
        window.addEventListener('hashchange', activateSectionFromHash);
    
        // Função para abrir/fechar navbar
        function toggleNavbar() {
            const navbar = document.getElementById('navbar');
            navbar.classList.toggle('open');
        }
    
        // Função para mudar de seção sem recarregar a página
        function changeSection(sectionId) {
            // Esconder todas as seções
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active');
            });
    
            // Mostrar a seção clicada
            document.getElementById(sectionId).classList.add('active');
        }
        // Função para abrir o modal
    function openModal(clientId) {
        document.getElementById('modal-' + clientId).style.display = "block";
    }
    
    // Função para fechar o modal
    function closeModal(clientId) {
        document.getElementById('modal-' + clientId).style.display = "none";
    }
    