<?php
// Conexão com o banco de dados
include 'includes/dashboard_head.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="SHORTCUT ICON" href="logo.png" type="image/x-icon" class="logo"/>
    <title>Dashboard</title>
</head>
<body>
    <!-- Navbar lateral -->
    <div class="navbar" id="navbar">
        <center><img src="logo.png" class="logo"></center>
        <div class="nav-header">Whatsapp<br>Service</div>
        <ul>
            <li><a href="#home" onclick="changeSection('home')">Home</a></li>
            <li><a href="whatsapp.php" onclick="changeSection('whatsapp')">Whatsapp</a></li>
            <li><a href="#sobre" onclick="changeSection('sobre')">Quem Somos</a></li>
            <li><a href="includes/logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Botão para abrir/fechar navbar -->
    <div class="navbar-toggle" id="toggleBtn" onclick="toggleNavbar()">☰</div>

    <!-- Conteúdo principal -->
    <div class="main-content" id="mainContent">
        <section id="home" class="section active">
            <div class="form-home">
                <div class="welcome-section">
                    <h1 class="text-center">Home</h1>
                    <p class="text-center">Bem-vindo ao painel, <strong><?php echo htmlspecialchars($nome_funcionario); ?></strong></p>
                </div>
                <br>
                <hr>
                <br>
                <div class="list-contacts">
                    <h3 class="text-center">Lista de Contatos</h3>
                    <p class="text-center">Aqui você encontra sua lista de contatos</p>
                    <ul class="contacts-list">
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <li>
                                <strong><?php echo htmlspecialchars(substr($row['nome_contato'], 0, 25)); ?></strong>
                                | <?php echo htmlspecialchars($row['numero']); ?>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                </div>
                <br>
                <hr>
                <br>
                <div class="upload-section">
                    <h3 class="text-center">Upload de Contatos</h3>
                    <p class="text-center">Você pode exportar sua lista de contatos em <a href="https://contacts.google.com/" target="_blank">Google Contacts</a></p>
                    <form action="includes/upload_contatos.php" method="post" enctype="multipart/form-data" class="upload-form">
                        <div class="form-group">
                            <label for="file">Selecione o arquivo .txt:</label>
                            <input type="file" name="file" id="file" accept=".csv" required>
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" class="btn-submit">Enviar</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>

        <section id="whatsapp" class="section">
            <br>
            <h1>Whatsapp Integration - Redirecionando...</h1>
            <br>
            <div class="form-container">
                <h2>whatsapp</h2>
                <br>
                <p>Redirecionando...</p>
            </div>
        </section>

        <section id="sobre" class="section">
            <div class="container-descoberta-lista">
                <div class="form-container">
                    <center>
                        <h1>SECURITYNET BRASIL</h1>
                        <h3>Gabriel Moura Machado</h3>
                    </center>
                    <div class="servicos">
                        <h2>Serviços</h2>
                        <ul>
                            <li><strong>Identidade Visual:</strong> Criação e desenvolvimento de logotipos e identidade de marca.</li>
                            <li><strong>Marketing Digital:</strong> Estratégias de marketing focadas em SEO, mídias sociais e publicidade online.</li>
                            <li><strong>Análise de Segurança:</strong> Avaliação de vulnerabilidades e implementação de medidas de proteção.</li>
                            <li><strong>Soluções em Tecnologia:</strong> Consultoria e implementação de soluções tecnológicas sob medida.</li>
                            <li><strong>Desenvolvimento de Aplicativos:</strong> Criação de aplicativos personalizados para diversas plataformas.</li>
                        </ul>
                    </div>
                    <br>
                    <hr>
                    <div class="plano-captura">
                        <h2>Plano de Captura de Clientes</h2>
                        <p>
                            Nosso plano utiliza um sistema automatizado que realiza pesquisas avançadas via Google Dorking para identificar sites e servidores vulneráveis. As vulnerabilidades incluem SQL Injection (SQLi), Cross-Site Scripting (XSS), Remote Code Execution (RCE), Local File Inclusion (LFI), Remote File Inclusion (RFI) e Insecure Direct Object Reference (IDOR).
                        </p>
                        <p>
                            O bot coleta informações via WHOIS e web scraping, gerando um relatório detalhado para os representantes comerciais, que utilizam essas informações para contatar potenciais clientes.
                        </p>
                    </div>
                    <br>
                    <hr>
                    <div class="roteiro-abordagem">
                        <h2>Roteiro de Abordagem</h2>
                        <a href="roteiro.html">
                            <p>Olá, eu sou o <strong>$REPRESENTANTE</strong>, representante comercial da SecurityNet Brasil...</p>
                        </a>
                    </div>
                    <br>
                    <hr>
                    <div class="colaboradores">
                        <h2>Colaboradores e Funções</h2>
                        <ul>
                            <li><strong>Gabriel Moura:</strong> Administrador Geral - Analista de Segurança e Desenvolvedor Back End</li>
                            <li><strong>Thiago TH:</strong> CEO - Designer e Representante comercial</li>
                            <li><strong>William Vasconcelos:</strong> Desenvolvedor - Designer e Representante comercial</li>
                        </ul>
                    </div>
                    <br>
                    <hr>
                    <div class="objetivo">
                        <h2>Objetivo</h2>
                        <p>
                            Nosso principal objetivo é construir uma base sólida de empresas-clientes que contribuam com uma mensalidade, visando o crescimento contínuo dessa lista. Isso garantirá uma receita estável e recorrente, proporcionando uma renda mensal consistente para todos os colaboradores.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script src="assets/js/script.js"></script>
</body>
</html>
