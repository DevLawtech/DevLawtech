<?php
// Conexão com o banco de dados
include 'includes/whats_configs.php';
if (preg_match('/Mobile/', $_SERVER['HTTP_USER_AGENT'])) {
    header('Location: m.whatsapp.php');
    exit();
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="SHORTCUT ICON" href="logo.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/zap_styles2.css">
    <title>WhatsApp Secnet</title>
</head>
<body>
    <div class="sidebar">
        <a href="dashboard.php#home"> &larr; </a>
        <h2>Contatos</h2>
        <div class="buttons-list">
            
            <button id="newCallBtn">New</button>
            <!-- O modal -->
            <div id="modal1">
                <div id="modal1Content">
                    <span class="close1">&times;</span>
                    <h2>Enviar Mensagem</h2>
                    <input type="text" id="phone_number" placeholder="Número do contato">
                    <textarea id="message" placeholder="Digite sua mensagem aqui"></textarea>
                    <button id="sendBtnmodal">Enviar</button>
                </div>
            </div>
            <button id="multi_call"><a href="multi_stream.php">Multi</a></button>
            <button id="multi_call"><a href="distribuited_stream.php">Massive</a></button>
        </div>
        <div class="contact-list"></div>
        <div class="buttons-list">
        <button id="erase_data" style="width:300px;">Clean</button></div>
    </div>

    <div class="chat-area">
        <div class="messages" id="messages">
            <p>Selecione um contato para ver as mensagens.</p>
        </div>

        <div class="input-area">
            <input type="text" id="messageInput" placeholder="Digite sua mensagem">
            <button id="sendButton">Enviar</button>
        </div>
    </div>
    
    <script src="assets/js/zap.js"></script>
</body>
</html>
