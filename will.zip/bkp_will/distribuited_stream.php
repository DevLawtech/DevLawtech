<?php
// Conexão com o banco de dados
include 'includes/db_connect.php';

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// URL da API
$url_api = 'http://localhost/whatsapp-service/api.php';

// Chave de autenticação
$api_key = 'batata';

// Função para enviar uma mensagem para um número de telefone
function enviarMensagem($contact, $message, $url_api, $api_key) {
    $payload = [
        'key' => $api_key,
        'phone_number' => $contact,
        'message' => $message
    ];

    $query = http_build_query($payload);
    $opts = ['http' => ['timeout' => 10]]; // Adicionar timeout
    $context = stream_context_create($opts);

    $response = @file_get_contents("$url_api?$query", false, $context);

    if ($response === FALSE) {
        return "Erro ao enviar mensagem para $contact.";
    } else {
        return "Mensagem enviada para $contact com sucesso!";
    }
}

// Obtém informações do usuário logado
$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM empresas WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user_result = $stmt->get_result();

if ($user_result->num_rows === 0) {
    die("Usuário não encontrado.");
}

$user = $user_result->fetch_assoc();
$nome_funcionario = $user['nome_completo'];
$cpf = $user['cpf'];

// Processa o envio das mensagens se o formulário for enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['contacts']) && isset($_POST['message'])) {
    $contacts = array_map('trim', explode(',', $_POST['contacts']));
    $message = $_POST['message'];
    $results = [];
    $contactCount = 0; // Contador de contatos enviados
    $currentApi = $url_api; // Inicia com a primeira API

    foreach ($contacts as $contact) {
        if (!empty($contact)) {
            // Envia a mensagem usando a API atual
            $results[] = enviarMensagem($contact, $message, $currentApi, $api_key);
            $contactCount++; // Incrementa o contador

            // Se 10 contatos foram enviados, aguarda 3 segundos e alterna a API
            if ($contactCount % 10 === 0) {
                sleep(3); // Pausa por 3 segundos
                // Alterna a API
                $currentApi = ($currentApi === $url_api) ? 'http://localhost/whatsapp-service/api2.php' : $url_api;
            }
        }
    }

    // Exibe os resultados
    $result_output = implode('', $results);
} else {
    $result_output = '';
}


// Consulta para obter os contatos armazenados no banco de dados
$query = "SELECT * FROM contatos WHERE owner = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $cpf);
$stmt->execute();
$result = $stmt->get_result();
$contacts_list = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $contacts_list[] = $row;
    }
}

$conn->close();

// Remover duplicatas
$contacts_list = array_unique(array_map('serialize', $contacts_list));
$contacts_list = array_map('unserialize', $contacts_list);

function formatarNumero($numero) {
    // Remover espaços, parênteses, traços e outros caracteres
    $numero = preg_replace('/\D/', '', $numero);

    // Verificar se o número já tem o prefixo do Brasil (55)
    if (substr($numero, 0, 2) !== '55') {
        $numero = '55' . $numero;
    }

    // Remover 0 após o 55 se existir
    if (substr($numero, 2, 1) === '0') {
        $numero = '55' . substr($numero, 3);
    }

    // Garantir que o número tenha no máximo 12 caracteres
    if (strlen($numero) > 12) {
        $numero = substr($numero, 0, 12);
    }

    return $numero; // Retorna o número formatado corretamente
}
?>



<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="SHORTCUT ICON" href="logo.png" type="image/x-icon" />
    <title>Enviar Mensagens em Massa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #f7f7f7;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 20px;
            margin-top: 20px;
            box-sizing: border-box;
            position: relative; /* Adicionado para o posicionamento absoluto do botão */
            display: flex;
            justify-content: space-between;
        }

        .form-section, .contacts-section {
            margin-top:100px;
            width: 48%;
        }

        .back-button {
            position: absolute;
            top: 10px;
            right: 10px;
            text-decoration: none;
            color: #4CAF50;
            font-size: 16px;
            font-weight: bold;
            background-color: #f7f7f7;
            border: 2px solid #4CAF50;
            padding: 8px 16px;
            border-radius: 4px;
            transition: background-color 0.3s, color 0.3s;
        }

        .back-button:hover {
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
        }

        h2 {
            margin-top: 0;
            color: #333;
        }

        textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            box-sizing: border-box;
            height: 120px;
            border: 1px solid #ddd;
            border-radius: 4px;
            resize: vertical;
        }

        button {
            padding: 12px 24px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }

        .result {
            margin-top: 20px;
            text-align: center;
        }

        .result h3 {
            color: #333;
        }

        .result p {
            color: #666;
            line-height: 1.6;
        }

        .contacts-list {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 4px;
            background-color: #f9f9f9;
            height:200px;
            overflow:auto;
            margin-top:50px;
        }

        .contacts-list h3 {
            margin-top: 0;
            color: #333;
        }

        .contacts-list ul {
            list-style-type: none;
            padding: 0;
        }

        .contacts-list ul li {
            padding: 5px 0;
            border-bottom: 1px solid #ddd;
        }

        .contacts-list ul li:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Seção do formulário -->
        <div class="form-section">
            <a class="back-button" href="whatsapp.php">&larr; Voltar</a>
            <h2>Enviar Mensagem para Múltiplos Contatos</h2>
            <form method="POST">
                <textarea name="contacts" placeholder="Digite números de telefone separados por vírgula (e.g., 123456789, 987654321)"></textarea>
                <textarea name="message" placeholder="Digite a mensagem aqui"></textarea>
                <button type="submit">Enviar</button>
            </form>

            <!-- Exibição dos resultados -->
            <div class="result">
                <?php if ($result_output): ?>
                    <h3>Resultados:</h3>
                    <script>alert("<?php echo $result_output; ?>")</script>
                <?php endif; ?>
            </div>
        </div>

        <!-- Seção da lista de contatos -->
        <div class="contacts-section">
            <h3>Lista de Contatos</h3>
            
            <div class="contacts-list">
                <ul>
                    <?php foreach ($contacts_list as $numero_unico): ?>
                        <li><?php echo formatarNumero($numero_unico['numero']); ?>,</li>
                        <?php endforeach; ?>
                        
                    </ul>
                </div>
                <br>
                <?php echo "contatos: ".count($contacts_list); ?>
        </div>
    </div>
</body>
</html>
